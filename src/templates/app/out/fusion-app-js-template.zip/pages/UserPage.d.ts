export declare const UserPage: () => JSX.Element;
export default UserPage;
