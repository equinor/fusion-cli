/**
 * User page
 *
 * @returns Users personal details
 */
export declare const UserPage: () => JSX.Element;
export default UserPage;
