export declare const AppsPage: () => JSX.Element;
