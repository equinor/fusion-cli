/**
 *
 * @returns Navigation with app list component
 */
export declare const AppsPage: () => JSX.Element;
