/**
 * Home Page
 *
 * @returns Navigation with few component examples and documentation for React Query
 * React Query @see (@link https://react-query.tanstack.com)
 */
export declare const HomePage: () => JSX.Element;
