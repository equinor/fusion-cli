export declare const HomePage: () => JSX.Element;
