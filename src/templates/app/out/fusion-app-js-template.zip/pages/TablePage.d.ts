import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
/**
 *
 * @returns AG grid table page for displaying fusion apps
 */
export declare const TablePage: () => JSX.Element;
export default TablePage;
