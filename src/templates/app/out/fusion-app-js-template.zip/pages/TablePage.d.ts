/**
 *
 * @returns AG Grid Table page for displaying fusion apps
 */
export declare const TablePage: () => JSX.Element;
export default TablePage;
