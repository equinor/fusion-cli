export declare const Layout: () => JSX.Element;
export default Layout;
