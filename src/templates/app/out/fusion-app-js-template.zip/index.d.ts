export declare const render: (fusion: import("@equinor/fusion-framework").Fusion, env: import("@equinor/fusion-framework").AppManifest) => import("react").LazyExoticComponent<import("react").ComponentType<{}>>;
export default render;
