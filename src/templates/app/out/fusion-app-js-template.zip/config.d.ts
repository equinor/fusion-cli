import { AppConfigurator } from '@equinor/fusion-framework-react-app';
export declare const configCallback: AppConfigurator;
export default configCallback;
