export declare const Router: () => JSX.Element;
export default Router;
