/**
 *
 * @returns Routes and Route for rendering different pages in React Router
 */
export declare const Router: () => JSX.Element;
export default Router;
