export declare const useAppStyle: (props?: {} | undefined) => import("@material-ui/styles").ClassNameMap<"hello" | "popover" | "container">;
export default useAppStyle;
