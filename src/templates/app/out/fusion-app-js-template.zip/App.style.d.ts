export declare const useAppStyle: (props?: {} | undefined) => import("@material-ui/styles").ClassNameMap<"hello" | "popover">;
export default useAppStyle;
