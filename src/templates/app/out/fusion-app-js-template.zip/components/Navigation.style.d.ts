export declare const useStyles: (props?: {} | undefined) => import("@material-ui/styles").ClassNameMap<"flex" | "root" | "breadcrumbs">;
export default useStyles;
