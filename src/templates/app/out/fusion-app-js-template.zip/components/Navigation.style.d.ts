export declare const useStyles: (props?: {} | undefined) => import("@material-ui/styles").ClassNameMap<"flex" | "root">;
export default useStyles;
