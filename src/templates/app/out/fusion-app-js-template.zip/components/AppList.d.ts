export declare const AppList: () => JSX.Element;
