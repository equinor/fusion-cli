/**
 *
 * @returns List of all fusion registered applications from the portal
 */
export declare const AppList: () => JSX.Element;
