import { App } from '../types';
declare type AppInfoProps = {
    app: App;
};
export declare const AppInfo: ({ app }: AppInfoProps) => JSX.Element;
export default AppInfo;
