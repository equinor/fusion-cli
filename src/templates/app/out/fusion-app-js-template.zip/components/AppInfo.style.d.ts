declare type AppInfoStyleProps = {
    color: string;
};
export declare const useStyles: (props: AppInfoStyleProps) => import("@material-ui/styles").ClassNameMap<"title" | "red" | "root">;
export default useStyles;
