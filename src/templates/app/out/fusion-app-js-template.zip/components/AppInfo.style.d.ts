declare type AppInfoStyleProps = {
    color: string;
};
export declare const useStyles: (props: AppInfoStyleProps) => import("@material-ui/styles").ClassNameMap<"title" | "root" | "app">;
export default useStyles;
