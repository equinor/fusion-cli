export declare const useStyles: (props?: {} | undefined) => import("@material-ui/styles").ClassNameMap<"title" | "root">;
export default useStyles;
