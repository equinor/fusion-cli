export declare const Navigation: () => JSX.Element;
