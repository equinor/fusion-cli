/**
 *
 * @returns Navigation drawer component
 */
export declare const Navigation: () => JSX.Element;
