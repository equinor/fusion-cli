export declare enum QueryKeys {
    GetAllApps = "GET_ALL_APPS"
}
