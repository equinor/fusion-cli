export declare const AppComponent: () => JSX.Element;
export default AppComponent;
