/**
 *
 * @returns Add React Router and ReactDev tool
 * React Router @see (@link https://reactrouterdotcom.fly.dev/docs/en/v6/getting-started/installation)
 * React Query @see (@link https://react-query.tanstack.com/quick-start)
 */
export declare const AppComponent: () => JSX.Element;
export default AppComponent;
